import { Component, Input } from '@angular/core';
import { KENDO_GRID } from "@progress/kendo-angular-grid";
import { Resource } from '../../Interfaces/Interfaces';
import { HttpAPIClientService } from '../../Services/http-api-client.service';
import { ConvertResponseToResourceArray } from '../../UtilityFunctions/UtilityFunction';
import { Router } from '@angular/router';
import { ModalPopUpComponent } from '../modal-pop-up/modal-pop-up.component';


@Component({
  selector: 'app-resource-grid',
  standalone: true,
  imports: [KENDO_GRID, ModalPopUpComponent],
  templateUrl: './resource-grid.component.html',
  styleUrl: './resource-grid.component.css'
})
export class ResourceGridComponent {
  empId!: number;
  displayModal: boolean = false;
  gridData: Array<Resource> = [];
  constructor(private httpAPIClientService: HttpAPIClientService, private router: Router) { }


  Log(param: any) {
    console.log("Hi");
    alert(param);
  }

  Sort(param: any) {
    console.log(param);
  }

  Filter(param: any) {
    console.log(param);
  }

  ngOnInit() {
    this.httpAPIClientService.GetResources().subscribe((response: any) => {
      console.log(response);
      if (response?.success) {
        this.gridData = ConvertResponseToResourceArray(response?.data);
        console.log(this.gridData);
        // this.gridData = (ConvertResponseToResourceresponse.data as Array<Resource>);
      }
    });
  }

  ngOnChanges() {
    // console.log("Grid Data", this.gridData);
  }

  EditResource(empId: number) {
    this.router.navigate([`/Edit/${empId}`]);
  }

  DeleteResource(empId: number) {
    this.empId = empId;
    this.displayModal = true;
  }


  HandleModalEvent(modalResponse: boolean) {
    if (modalResponse) {
      this.httpAPIClientService.DeleteResource(this.empId).subscribe((response: any) => {
        if (response?.success) {
          this.router.navigate(['/']);
        }
      });
    }
    this.displayModal = false;
  }
}