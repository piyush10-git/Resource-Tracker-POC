import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Resource } from '../../Interfaces/Interfaces';
import { HttpAPIClientService } from '../../Services/http-api-client.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ConvertResourceToRequest, ConvertResponseToResource } from '../../UtilityFunctions/UtilityFunction';
import { ModalPopUpComponent } from '../modal-pop-up/modal-pop-up.component';

@Component({
  selector: 'app-employee-input-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, ModalPopUpComponent],
  templateUrl: './employee-input-form.component.html',
  styleUrl: './employee-input-form.component.css'
})
export class EmployeeInputFormComponent {
  constructor(private httpApiClient: HttpAPIClientService, private router: Router, private activatedRoute: ActivatedRoute) { }
  displayModal: boolean = false;
  loading: boolean = false;
  isEditMode = false;
  empId!: number;

  intialEditState!: any;

  employeeForm: FormGroup = new FormGroup({
    resourceName: new FormControl('', [Validators.required]),
    emailId: new FormControl('', [Validators.required, Validators.email]),
    cteDoj: new FormControl('', [Validators.required]),
    location: new FormControl('', [Validators.required]),

    designation: new FormControl('', [Validators.required]),
    reportingTo: new FormControl('', [Validators.required]),
    billable: new FormControl('', [Validators.required]),

    technologySkill: new FormControl('', [Validators.required]),
    projectAllocation: new FormControl('', Validators.required),

    remarks: new FormControl(''),
  })

  ngOnInit() {
    this.loading = true;
    this.empId = +this.activatedRoute.snapshot.paramMap.get('empId')!;
    if (this.empId) {
      console.log(this.empId);
      
      this.isEditMode = true;
      this.httpApiClient.GetResourceById(this.empId).subscribe((response: any) => {
        console.log(response);
        if (response?.success) {
          let data = ConvertResponseToResource(response.data);
          this.employeeForm.patchValue(data);
          this.intialEditState = { ...data };
        }
        this.loading = false;
      })
    } else {
      this.isEditMode = false;
      this.loading = false;
    }
  }

  OnFormSubmit() {
    this.loading = true;
    if (!this.employeeForm.valid) return;

    let requestBody = ConvertResourceToRequest(this.employeeForm.value);

    if (!this.isEditMode) {
      console.log(requestBody);
      this.httpApiClient.CreateResource(requestBody).subscribe((response: any) => {
        console.log(response);
        if (response?.success) {
          console.log(response);
          this.ResetForm();
          this.loading = false;
        }
      });
    } else {
      requestBody['empId'] = this.empId;
      console.log(requestBody);
      this.httpApiClient.UpdateResource(requestBody).subscribe((response: any) => {
        console.log(response);
        if (response?.success) {
          this.router.navigate(['/Resource-Grid']);
          this.loading = false;
        }
      });
    }
  }


  ResetForm() {
    if (this.isEditMode) {
      this.employeeForm.patchValue(this.intialEditState);
    } else {
      this.employeeForm.reset();
    }
  }

  HandleModalEvent(value: boolean) {
    if (value) {
      this.ResetForm();
    }
    this.displayModal = false;
  }

  getValidation(controlName: string, Validators: Array<string>) {
    let formControl = this.employeeForm.controls?.[controlName];
    if (!formControl.dirty && !formControl.touched) {
      return false;
    }
    for (let validator of Validators) {
      if (formControl?.errors?.[validator]) {
        return true;
      }
    }
    return false;
  }

  GetModalHeader() {
    return this.isEditMode ? "Are you sure you want to reset changes?" : "Are you sure you want to clear the form?";
  }

  GetModalContent() {
    return '';
    return this.isEditMode ? "All unsaved updates will be discarded and the original values will be restored." : "All entered information will be lost.";
  }

  GetPositiveContent() {
    return this.isEditMode ? "Yes, discard changes" : "Yes, reset";
  }
} 