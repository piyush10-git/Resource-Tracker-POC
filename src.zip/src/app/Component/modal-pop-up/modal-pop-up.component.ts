import { CommonModule } from '@angular/common';
import { Component, EventEmitter, input, Input, Output } from '@angular/core';

@Component({
  selector: 'app-modal-pop-up',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './modal-pop-up.component.html',
  styleUrl: './modal-pop-up.component.css'
})
export class ModalPopUpComponent {
  @Input() isVisible: boolean = false;
  @Input('content') modalContent: string = '';
  @Input('positive-content') positiveBtnContent: string = '';
  @Input('negative-content') negativeBtnContent: string = '';
  @Input('modal-header') modalHeader: string = '';

  @Output('modal-event-handler') modalEventEmitter = new EventEmitter<boolean>();

  OnButtonClick(value: boolean) {
    this.modalEventEmitter.emit(value);
  }
}
