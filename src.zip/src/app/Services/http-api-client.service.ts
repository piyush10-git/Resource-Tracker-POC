import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HttpAPIClientService {
  private serverURI: string = "http://localhost:5150/resources";
  
  constructor(private httpClient: HttpClient) { }

  GetResources() {
    const endpointURI = this.serverURI;
    return this.httpClient.get(endpointURI);
  }

  GetResourceById(id: number) {
    const endpointURI = this.serverURI + `/${id}`;
    return this.httpClient.get(endpointURI);
  }

  GetResourceStatistics() {
    const endpointURI = this.serverURI + '/statistics';
    return this.httpClient.get(endpointURI);
  }

  CreateResource(data: any) {
    const endpointURI = this.serverURI;
    return this.httpClient.post(endpointURI, data);
  }

  UpdateResource(data: any) {
    const endpointURI = this.serverURI;
    return this.httpClient.put(endpointURI, data);
  }

  DeleteResource(id: number) {
    const endpointURI = this.serverURI + `/${id}`;
    return this.httpClient.delete(endpointURI);
  }
}
